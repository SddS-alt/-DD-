
'use client'
import Image from 'next/image'
import Link from 'next/link'
import Header from '../components/Header'
import Cart from '../components/Cart'
import products from '../data/products.json'
import React from 'react'

export default function Shop(){
  const [items, setItems] = React.useState([])
  const [open, setOpen] = React.useState(false)

  React.useEffect(()=>{
    const saved = localStorage.getItem('dd_cart')
    if (saved) setItems(JSON.parse(saved))
  },[])

  React.useEffect(()=>{
    localStorage.setItem('dd_cart', JSON.stringify(items))
  },[items])

  const add = (p)=>{
    const size = p.sizes[0]
    const found = items.find(i=> i.id===p.id && i.size===size)
    if(found){
      setItems(items.map(i=> i===found? {...i, qty:i.qty+1}:i))
    } else {
      setItems([...items, {id:p.id, name:p.name, price:p.price, image:p.images[0], size, qty:1}])
    }
    setOpen(true)
  }

  const subtotal = items.reduce((a,b)=> a + b.price*b.qty, 0)
  const tax = subtotal * 0.0775
  const total = subtotal + tax

  const checkout = async ()=>{
    try{
      const res = await fetch('/api/checkout', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ items })
      })
      const data = await res.json()
      if(data?.url) window.location = data.url
      else alert('Checkout error: ' + (data?.error || 'Unknown'))
    }catch(e){
      alert('Checkout failed')
    }
  }

  return (
    <main style={{background:'#0a0a0a', minHeight:'100vh', color:'#fff'}}>
      <Header onOpenCart={()=> setOpen(true)} cartCount={items.reduce((a,b)=>a+b.qty,0)} />
      <section className="container" style={{padding:'28px 0'}}>
        <h2>Shop</h2>
        <div className="grid" style={{marginTop:16}}>
          {products.map(p=> (
            <div key={p.id} className="card">
              <Image src={p.images[0]} alt={p.name} width={900} height={700} />
              <div className="card-body">
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                  <div>
                    <div style={{fontWeight:800}}>{p.name}</div>
                    <div className="small">{p.category}</div>
                  </div>
                  <div className="price">${p.price.toFixed(2)}</div>
                </div>
                <div style={{display:'flex', gap:8, marginTop:10}}>
                  <button className="btn" onClick={()=> add(p)}>Add to Cart</button>
                  <Link className="btn secondary" href={`/shop/${p.id}`}>Details</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
      <Cart open={open} onClose={()=> setOpen(false)} items={items} setItems={setItems} onCheckout={checkout} totals={{subtotal, tax, total}} />
    </main>
  )
}
