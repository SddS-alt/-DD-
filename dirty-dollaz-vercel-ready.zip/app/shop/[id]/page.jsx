
'use client'
import Image from 'next/image'
import { useParams } from 'next/navigation'
import Header from '../../components/Header'
import products from '../../data/products.json'
import Cart from '../../components/Cart'
import React from 'react'

export default function ProductPage(){
  const { id } = useParams()
  const p = products.find(x=> x.id===id)
  const [size, setSize] = React.useState(p?.sizes?.[0])
  const [items, setItems] = React.useState([])
  const [open, setOpen] = React.useState(false)

  React.useEffect(()=>{ const s = localStorage.getItem('dd_cart'); if(s) setItems(JSON.parse(s)) },[])
  React.useEffect(()=>{ localStorage.setItem('dd_cart', JSON.stringify(items)) },[items])

  const add = ()=>{
    const found = items.find(i=> i.id===p.id && i.size===size)
    if(found) setItems(items.map(i=> i===found ? {...i, qty:i.qty+1}: i))
    else setItems([...items, {id:p.id, name:p.name, price:p.price, image:p.images[0], size, qty:1}])
    setOpen(true)
  }

  const subtotal = items.reduce((a,b)=> a + b.price*b.qty, 0)
  const tax = subtotal * 0.0775
  const total = subtotal + tax
  const checkout = async ()=>{
    const res = await fetch('/api/checkout',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({items})})
    const data = await res.json()
    if(data?.url) window.location = data.url; else alert('Checkout error')
  }

  if(!p) return <div style={{color:'#fff'}}>Not found</div>
  return (
    <main style={{background:'#0a0a0a', minHeight:'100vh', color:'#fff'}}>
      <Header onOpenCart={()=> setOpen(true)} cartCount={items.reduce((a,b)=>a+b.qty,0)} />
      <section className="container" style={{padding:'28px 0'}}>
        <div style={{display:'grid', gridTemplateColumns:'1fr', gap:18}}>
          <Image src={p.images[0]} alt={p.name} width={1000} height={800} style={{borderRadius:14}}/>
          <div className="card">
            <div className="card-body">
              <h2>{p.name}</h2>
              <div className="price">${p.price.toFixed(2)}</div>
              <p className="small" style={{marginTop:8}}>{p.description}</p>
              <div style={{display:'flex', gap:8, marginTop:12}}>
                {p.sizes.map(s=> (
                  <button key={s} className={`btn ${s===size?'':'secondary'}`} onClick={()=> setSize(s)}>{s}</button>
                ))}
              </div>
              <div style={{display:'flex', gap:8, marginTop:14}}>
                <button className="btn" onClick={add}>Add to Cart</button>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Cart open={open} onClose={()=> setOpen(false)} items={items} setItems={setItems} onCheckout={checkout} totals={{subtotal, tax, total}} />
    </main>
  )
}
