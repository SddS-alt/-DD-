
import products from './data/products.json'
export function listProducts(){ return products }
export function getProduct(id){ return products.find(p=>p.id===id) }
