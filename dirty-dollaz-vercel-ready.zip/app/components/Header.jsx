
'use client'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'

export default function Header({ onOpenCart, cartCount=0 }){
  const path = usePathname()
  const is = (p)=> path===p ? 'active' : ''
  return (
    <header className="header">
      <div className="container header-inner">
        <Link href="/" className="brand">
          <span className="brand-mark">$</span>
          <span className="logo-text">Dirty Dollaz</span>
        </Link>
        <nav className="nav">
          <Link className={is('/shop')} href="/shop">Shop</Link>
          <Link className={is('/about')} href="/about">About</Link>
          <Link className={is('/contact')} href="/contact">Contact</Link>
        </nav>
        <button className="btn secondary" onClick={onOpenCart}>Cart ({cartCount})</button>
      </div>
    </header>
  )
}
