
'use client'
import Image from 'next/image'
import Link from 'next/link'

export default function Cart({open, onClose, items, setItems, onCheckout, totals}){
  const remove = (i)=> setItems(items.filter((_,idx)=> idx!==i))
  const setQty = (i, qty)=> setItems(items.map((l,idx)=> idx===i ? {...l, qty: Math.max(1, +qty||1)} : l))
  return (
    <aside className={`cart ${open?'open':''}`}>
      <div className="cart-header">
        <strong>Your Cart</strong>
        <button className="btn secondary" onClick={onClose}>Close</button>
      </div>
      <div className="cart-body">
        {items.length===0 && <div className="small">Your cart is empty.</div>}
        {items.map((l, i)=> (
          <div key={i} style={{display:'flex', gap:10, alignItems:'center'}}>
            <Image src={l.image} alt={l.name} width={68} height={68} style={{borderRadius:8, objectFit:'cover'}}/>
            <div style={{flex:1}}>
              <div style={{fontWeight:700}}>{l.name}</div>
              <div className="small">Size {l.size}</div>
              <input className="input" type="number" min="1" value={l.qty} onChange={(e)=> setQty(i, e.target.value)} style={{width:88, marginTop:6}}/>
            </div>
            <div>${(l.price * l.qty).toFixed(2)}</div>
            <button className="btn secondary" onClick={()=> remove(i)}>Remove</button>
          </div>
        ))}
      </div>
      <div className="cart-footer">
        <div className="small" style={{display:'flex', justifyContent:'space-between'}}><span>Subtotal</span><span>${totals.subtotal.toFixed(2)}</span></div>
        <div className="small" style={{display:'flex', justifyContent:'space-between'}}><span>Tax (7.75%)</span><span>${totals.tax.toFixed(2)}</span></div>
        <div style={{display:'flex', justifyContent:'space-between', margin:'8px 0', fontWeight:800}}><span>Total</span><span>${totals.total.toFixed(2)}</span></div>
        <button className="btn" onClick={onCheckout} style={{width:'100%'}}>Checkout</button>
        <div className="small" style={{marginTop:8}}>Checkout uses Stripe. Set environment variables in Vercel.</div>
      </div>
    </aside>
  )
}
