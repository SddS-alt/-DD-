
import Link from 'next/link'
import Image from 'next/image'
import './globals.css'
import Header from './components/Header'

export default function HomePage(){
  return (
    <main style={{background:'#0a0a0a', minHeight:'100vh', color:'#fff'}}>
      <Header />
      <section className="hero">
        <div className="container hero-inner">
          <div>
            <div style={{color:'#bbb'}}>Streetwear built for</div>
            <h1 style={{fontFamily:'UnifrakturCook,serif', fontSize:72, lineHeight:1, marginTop:6}}>Dirty Dollaz</h1>
            <p style={{maxWidth:520, color:'#bdbdbd', marginTop:12}}>Bold silhouettes. Old English energy. Limited drops crafted for the hustle.</p>
            <div style={{display:'flex', gap:12, marginTop:18}}>
              <Link className="btn" href="/shop">Shop the Drop</Link>
              <Link className="btn secondary" href="/about">Learn more</Link>
            </div>
          </div>
          <div className="grid">
            <div className="card">
              <Image src="/al-capone-front.png" alt="Al Capone Hoodie" width={800} height={600}/>
              <div className="card-body">
                <div style={{display:'flex', justifyContent:'space-between'}}>
                  <strong>Al Capone Hoodie</strong><span className="price">$34.99</span>
                </div>
              </div>
            </div>
            <div className="card">
              <Image src="/tee-front.png" alt="Slim Fit Tee" width={800} height={600}/>
              <div className="card-body">
                <div style={{display:'flex', justifyContent:'space-between'}}>
                  <strong>Slim Fit Tee</strong><span className="price">$13.99</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <footer className="footer">
        <div className="container" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div>
            <div style={{fontFamily:'UnifrakturCook,serif', fontSize:26}}>Dirty Dollaz</div>
            <div className="small">© {new Date().getFullYear()} Dirty Dollaz</div>
          </div>
          <div className="small">Fast Shipping • Secure Checkout • Limited Runs</div>
        </div>
      </footer>
    </main>
  )
}
