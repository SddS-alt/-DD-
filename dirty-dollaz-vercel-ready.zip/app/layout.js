
export const metadata = {
  title: "Dirty Dollaz",
  description: "Dirty Dollaz — Streetwear built for the hustle."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=UnifrakturCook:wght@700&family=Inter:wght@400;600;800&display=swap" rel="stylesheet" />
      </head>
      <body style={{margin:0,fontFamily:'Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial'}}>
        {children}
      </body>
    </html>
  );
}
